console.log('Design Patterns');
