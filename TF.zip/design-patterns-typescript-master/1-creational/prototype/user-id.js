"use strict";
exports.__esModule = true;
exports.UserId = void 0;
var UserId = /** @class */ (function () {
    function UserId(id) {
        this.id = id;
    }
    return UserId;
}());
exports.UserId = UserId;
