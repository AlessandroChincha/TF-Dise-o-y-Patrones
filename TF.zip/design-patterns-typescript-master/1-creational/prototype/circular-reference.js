"use strict";
exports.__esModule = true;
exports.CircularReference = void 0;
var CircularReference = /** @class */ (function () {
    function CircularReference(prototype) {
        this.prototype = prototype;
    }
    return CircularReference;
}());
exports.CircularReference = CircularReference;
