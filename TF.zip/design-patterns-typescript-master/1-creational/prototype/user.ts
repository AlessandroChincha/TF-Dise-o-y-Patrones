import { UserId } from "./user-id";
import { EmailUser } from "./user-id";
import { NumeroUsuario } from "./user-id";
import { DNIUser } from "./user-id";
export class User {
    public id: UserId; // Object Reference
    public email: EmailUser; // Primitive
    public number: NumeroUsuario;
    public DNI:NumeroUsuario;
    public deepCopy(): this {
        const clone = Object.create(this);
        clone.id = Object.create(this.id);
        clone.email=Object.create(this.email);
        clone.DNI = Object.create(this.DNI);
        clone.number = Object.create(this.number);
        
        /*clone.preference = {
            ...this.preference,
            user: { ...this },
        };*/

        return clone;
    }
}
