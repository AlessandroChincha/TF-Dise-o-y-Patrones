export class UserId {
  public id: number;

  constructor(id: number) {
    this.id = id;
  }
}

export class EmailUser{
  public Email: string;

  constructor(email:string){
    this.Email=email
  }
}
export class NumeroUsuario{
  public Numero:number;
  constructor(Numero:number){
    this.Numero=Numero;
  }
}
export class DNIUser{
  public DNI:number;
  constructor(DNI:number){
    this.DNI=DNI;
  }
}
export class MetodoPago{
  public Tarjeta:number;
  constructor(Tarjeta:number){
    this.Tarjeta=Tarjeta;
  }
}