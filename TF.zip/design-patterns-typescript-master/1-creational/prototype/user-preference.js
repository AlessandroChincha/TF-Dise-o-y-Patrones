"use strict";
exports.__esModule = true;
exports.UserPreference = void 0;
var UserPreference = /** @class */ (function () {
    function UserPreference(user) {
        this.user = user;
    }
    return UserPreference;
}());
exports.UserPreference = UserPreference;
