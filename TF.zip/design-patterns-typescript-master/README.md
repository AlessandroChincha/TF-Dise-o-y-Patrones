# Install Typescript
```
$ npm install -g typescript
```

# Run index.ts file
## Windows
```
$ tsc index.ts | node index.js
```

## Mac
```
$ tsc index.ts && node index.js
```