import { IdNumber } from '../../../common/domain/value-objects/id-number.value';

export class UserId extends IdNumber {
}