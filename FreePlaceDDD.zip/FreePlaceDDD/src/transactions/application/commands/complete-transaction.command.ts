export class CompleteTransaction {
  constructor(
    public readonly transactionId: number
  ) {}
}