import { ChildEntity, Column, Unique } from 'typeorm';
import { ClientTypeORM } from './client.typeorm';
import { EmailTypeORM } from '../value-objects/EmailTypeORM';
import { PersonNameTypeORM } from '../value-objects/NameTypeORM';
import { ClientType } from '../../../../domain/enums/client-type.enum';

@ChildEntity(ClientType.PERSON)
export class PersonTypeORM extends ClientTypeORM {
  @Column((type) => PersonNameTypeORM, { prefix: false })
  public name: PersonNameTypeORM;

  @Column((type) => EmailTypeORM, { prefix: false })
  public dni: EmailTypeORM;
}