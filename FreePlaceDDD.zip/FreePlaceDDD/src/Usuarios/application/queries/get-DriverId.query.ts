export class GetCustomersCompanyQuery {
    constructor(readonly id:number){}
}