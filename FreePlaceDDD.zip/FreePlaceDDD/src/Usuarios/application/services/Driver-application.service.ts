import { Injectable } from '@nestjs/common';
import { CommandBus, QueryBus } from '@nestjs/cqrs';
import { AppNotification } from 'src/common/application/app.notification';
import { Result } from 'typescript-result';
import { RegisterCompanyValidator } from '../validators/register-company.validator';
import { RegisterCompanyRequest } from '../dtos/request/register-company-request.dto';
import { RegisterCompanyResponse } from '../dtos/response/register-company-response.dto';
import { DateTime } from '../../../common/domain/value-objects/date-time.value';
import { AppSettings } from '../../../common/application/app-settings';
import { IdDriverAplicator } from '../validators/DriverValidator';
import { UpdateDriverDTO } from '../validators/UpdateValidator';
import { GetDriverByIdResponseDto } from 'src/clients/response/GetDriverByID';
import { GetAccountByIdQuery } from 'src/accounts/application/queries/get-account-by-id.query';
import { RegisterDriverResponseDto } from 'src/clients/response/RegisterDriverResponse';
import { DriverID } from 'src/clients/domain/value-objects/Driveridvalues';
import { RegisterDriverCommand } from '../commands/register-driver.command';
import { UpdateDriverRequestDto } from '../dtos/request/Driver-updatedto';
import { DriverResponseDto } from 'src/clients/response/UpdateDriverResponse';
import { UpdateDriverCommand } from '../commands/UpdateDriverCommand';
import { DeleteDriverCommand } from '../commands/DeleteDriverCommand';
@Injectable()
export class CompanyApplicationService {
  constructor(
    private commandBus: CommandBus,
    private registerCompanyValidator: RegisterCompanyValidator,
    private queryBus: QueryBus,
    private idValidator:  IdDriverAplicator,
    private updateValidator:  UpdateDriverDTO
  ) {}
    async getByID(id:number,): Promise<Result<AppNotification,GetDriverByIdResponseDto>>{
      const Notifi: AppNotification = await this.idValidator.validate(id);
      if(Notifi.hasErrors()){
        return Result.error(Notifi);
      }
      const getDriverIDQuery:GetAccountByIdQuery=new GetAccountByIdQuery(id);
      const DriverTypeORM = await this.queryBus.execute(getDriverIDQuery);
      const getDriverByIdResponseDto: GetDriverByIdResponseDto= new GetDriverByIdResponseDto(
        DriverTypeORM.id.value,
        DriverTypeORM.name.firstName,
        DriverTypeORM.name.lastName,
        DriverTypeORM.email.value,
        DriverTypeORM.password.value,
        DriverTypeORM.mySpecialty,
        DriverTypeORM.myExperience,
        DriverTypeORM.description,
        DriverTypeORM.img,);
        return Result.ok(getDriverByIdResponseDto);
    }
    async getAllRepositoriesById(
      id: number,
    ): Promise<Result<AppNotification, string[]>> {
      const notification: AppNotification = await this.idValidator.validate(id);
  
      if (notification.hasErrors()) {
        return Result.error(notification);
      }
      const getDriverIDQuery: GetAccountByIdQuery=new GetAccountByIdQuery(id);
      const DriverTypeORM = await this.queryBus.execute(getDriverIDQuery);
      
      return Result.ok(notification);
  }
  async register(
    registerDriverResponseDto: RegisterDriverResponseDto,
  ): Promise<Result<AppNotification, RegisterDriverResponseDto>> {
    const notification: AppNotification =
      await this.registerCompanyValidator.validate(
        registerDriverResponseDto,
      );

    if (notification.hasErrors()) {
      return Result.error(notification);
    }

    const registerDriverCommand: RegisterDriverCommand =
      new RegisterDriverCommand(
        registerDriverCommand.firstName,
        registerDriverCommand.lastName,
        registerDriverCommand.email,
        registerDriverCommand.password,
        registerDriverCommand.mySpecialty,
        registerDriverCommand.myExperience,
        registerDriverCommand.description,
        registerDriverCommand.img,
      );
    const DriverId = await this.commandBus.execute(registerDriverCommand);

    const registerDriverResponseDto: RegisterDriverResponseDto =
      new RegisterDriverResponseDto(
        DriverId,
        registerDriverResponseDto.firstName,
        registerDriverResponseDto.lastName,
        registerDriverResponseDto.email,
        registerDriverResponseDto.password,
        registerDriverResponseDto.mySpecialty,
        registerDriverResponseDto.myExperience,
        registerDriverResponseDto.description,
        registerDriverResponseDto.img,
      );

    return Result.ok(registerDriverResponseDto);
  }
  async update(
    id: number,
    updateDriverRequestDto: DriverResponseDto,
  ): Promise<Result<AppNotification, DriverResponseDto>> {
    const notification: AppNotification =
      await this.registerCompanyValidator.validate(
        id,
        updateDriverRequestDto,
      );

    if (notification.hasErrors()) {
      return Result.error(notification);
    }

    const updateDriverCommand: UpdateDriverCommand =
      new UpdateDriverCommand(
        updateDriverCommand.firstName,
        updateDriverCommand.lastName,
        updateDriverCommand.email,
        updateDriverCommand.password,
        updateDriverCommand.mySpecialty,
        updateDriverCommand.myExperience,
        updateDriverCommand.description,
        updateDriverCommand.img,
      );
    const DriverTypeORM = await this.commandBus.execute(
      UpdateDriverDTO,
    );

    const updateApplicantResponseDto: DriverResponseDto =
      new DriverResponseDto(
        applicantTypeORM.id.value,
        applicantTypeORM.name.firstName,
        applicantTypeORM.name.lastName,
        applicantTypeORM.email.value,
        applicantTypeORM.password.value,
        applicantTypeORM.mySpecialty,
        applicantTypeORM.myExperience,
        applicantTypeORM.description,
        applicantTypeORM.nameGithub,
        applicantTypeORM.imgApplicant,
      );

    return Result.ok(updateApplicantResponseDto);
  }
}