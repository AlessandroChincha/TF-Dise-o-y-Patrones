export class GetCustomersPersonDto {
  public id: number;
  public firstName: string;
  public lastName: string;
  public dni: string;
}