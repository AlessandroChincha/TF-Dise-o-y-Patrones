export class GetCustomersCompanyDto {
  public id: number;
  public companyName: string;
  public ruc: string;
}