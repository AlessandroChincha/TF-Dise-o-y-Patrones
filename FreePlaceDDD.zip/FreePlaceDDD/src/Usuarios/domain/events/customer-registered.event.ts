export class CustomerRegistered {
  constructor(public readonly id: number) {}
}