export enum ClientType {
  COMPANY = 'C',
  PERSON = 'P'
}