export class GetAccountByIdQuery {
  public constructor(
    public readonly accountId: number) {}
}