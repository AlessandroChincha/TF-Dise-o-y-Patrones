export class GetAccountsDto {
  public id: number;
  public number: string;
  public balance: number;
  public currency: string;
  public clientId: number;
  public createdAt: string;
  public createdBy: number;
  public updatedAt: string;
  public updatedBy: number;
}