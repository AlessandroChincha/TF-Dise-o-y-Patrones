export class OpenAccount {
  constructor(
    public readonly clientId: number,
    public readonly number: string
  ) {}
}