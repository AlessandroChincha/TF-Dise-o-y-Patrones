export class AppSettings {
  public static SUPER_ADMIN = 1
}