export class GetCustomersPersonQuery {
}