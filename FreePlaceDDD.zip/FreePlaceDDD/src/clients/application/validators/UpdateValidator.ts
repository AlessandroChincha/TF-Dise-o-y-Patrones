import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { UpdateDriverRequestDto } from '../dtos/request/Driver-updatedto';
import { AppNotification } from 'src/common/application/app.notification';
import { Email } from 'src/common/domain/value-objects/email.value';
import { Result } from 'typescript-result';
import { Password } from 'src/common/domain/value-objects/password.value';
import { DriverID } from 'src/clients/domain/value-objects/Driveridvalues';
import { ClientTypeORM } from 'src/clients/infrastructure/persistence/typeorm/entities/client.typeorm';
import { DriverTypeORM } from 'src/clients/infrastructure/persistence/typeorm/entities/DriverTypeORM';
export class UpdateDriverDTO{
    constructor(
        @InjectRepository(DriverTypeORM)
        private DriverRepo:Repository<DriverTypeORM>,
    ){}
    public async validate(
        targetID: number,
        updateDriverRequestDTO:UpdateDriverRequestDto,
    ): Promise<AppNotification>{
        const Notifi: AppNotification = new AppNotification();
        const id: number=updateDriverRequestDTO.id;
        if(id==null){
            Notifi.addError('Driver ID is required', null);
        }
        const firstName: string = updateDriverRequestDTO.firstName.trim()
        if(firstName.length<=0){
            Notifi.addError('First Name is required',null);
        }
        const lastName: string = updateDriverRequestDTO.lastName.trim()
        if (lastName.length<=0) {
            Notifi.addError('Last Name is required',null);
        }
        const password: string = updateDriverRequestDTO.password.trim();

    if (password.length <= 0) {
      Notifi.addError('Driver password is required', null);
    }
    const email:string = updateDriverRequestDTO.email.trim()
    if(email.length<=0){
        Notifi.addError('Driver email is requiered', null);
    }
    const myExperience: string = updateDriverRequestDTO.myExperience.trim();

    if (myExperience.length <= 0) {
      Notifi.addError('Driver myExperience is required', null);
    }

    const description: string = updateDriverRequestDTO.description.trim();

    if (description.length <= 0) {
      Notifi.addError('Driver description is required', null);
    }

    const Img: string = updateDriverRequestDTO.imgApplicant.trim();

    if (Img.length <= 0) {
      Notifi.addError('Img is required', null);
    }

    if (Notifi.hasErrors()) {
      return Notifi;
    }
    const nameResult: Result<AppNotification,DriverID> = DriverID.create(
        firstName,
        lastName,
      );
    if(nameResult.isFailure()){
        Notifi.addError(nameResult.error.getError(),null);
    }
    const emailResult: Result<AppNotification,Email> = Email.create(email);
    if(emailResult.isFailure()){
        Notifi.addError(emailResult.error.getError(),null);
    }
    const passwordResult: Result<AppNotification,Password> = Password.create(password)
    if(passwordResult.isFailure()){
        Notifi.addError(emailResult.error.getError(),null);
    }
    if(Notifi.hasErrors()){
        return Notifi;
    }
    const Driver: DriverTypeORM = await this.DriverRepo.findOne(targetID);
    let otherDriver: DriverTypeORM=await this.DriverRepo.findOne(id);
    if(otherDriver!=null && otherDriver.id.value !==Driver.id.value){
        Notifi.addError( `There is already an driver with id: ${id}`,
        null,);
    }
    otherDriver = await this.DriverRepo.createQueryBuilder().where('email=:email', {email}).getOne();
    if(Driver!=null && otherDriver.email.value){
        Notifi.addError('Driver email is taken', null);
    }
    return Notifi
    }
}