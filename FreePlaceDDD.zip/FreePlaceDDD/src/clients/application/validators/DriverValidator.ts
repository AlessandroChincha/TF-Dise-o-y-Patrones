import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AppNotification } from '../../../common/application/app.notification';
import { ClientTypeORM } from 'src/clients/infrastructure/persistence/typeorm/entities/client.typeorm';

export class IdDriverAplicator{
    constructor(
        @InjectRepository(ClientTypeORM)
        private DriverRepository: Repository<ClientTypeORM>,
    ){}

public async validate(id: number): Promise<AppNotification>{
    const notification: AppNotification= new AppNotification();
    if(id<0){
        notification.addError(
            'Driver id most be positive', null,
        );
    }
    if (notification.hasErrors()){
        return notification;
    }
    const Driver: ClientTypeORM = await this.DriverRepository.findOne(id,);
    if(Driver==null){
        notification.addError(`There is no Driver with id: ${id}`, null);
    }
    return notification
}
}