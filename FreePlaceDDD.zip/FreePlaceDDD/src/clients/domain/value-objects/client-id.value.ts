import { IdNumber } from '../../../common/domain/value-objects/id-number.value';

export class ClientId extends IdNumber {
}