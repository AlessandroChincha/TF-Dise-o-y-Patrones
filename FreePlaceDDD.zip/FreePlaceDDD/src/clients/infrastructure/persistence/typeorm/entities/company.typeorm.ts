import { ChildEntity, Column, Unique } from 'typeorm';
import { ClientTypeORM } from './client.typeorm';
import { PasswordTypeORM } from '../value-objects/PasswordTypeORM';
import { CompanyNameTypeORM } from '../value-objects/company-name.typeorm';
import { ClientType } from '../../../../domain/enums/client-type.enum';

@ChildEntity(ClientType.COMPANY)
export class CompanyTypeORM extends ClientTypeORM {
  @Column((type) => CompanyNameTypeORM, { prefix: false })
  public companyName: CompanyNameTypeORM;

  @Column((type) => PasswordTypeORM, { prefix: false })
  public ruc: PasswordTypeORM;
}