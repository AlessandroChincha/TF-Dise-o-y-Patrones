import { Column, Entity, Unique } from 'typeorm';
import { DriverIDORM } from './DriverIdORM';
import { EmailTypeORM } from '../value-objects/EmailTypeORM';
import { PersonNameTypeORM } from '../value-objects/NameTypeORM';
import { PasswordTypeORM } from '../value-objects/PasswordTypeORM';

@Entity('Drivers')
@Unique('UQ_applicants',['email.value'])
export class DriverTypeORM{
    @Column((type)=> DriverIDORM, {prefix: false})
    public id:DriverIDORM;
    @Column((type) => DriverIDORM, { prefix: false })
    public name: DriverIDORM;
  
    @Column((type) => EmailTypeORM, { prefix: false })
    public email: EmailTypeORM;
  
    @Column((type) => PasswordTypeORM, { prefix: false })
    public password: PasswordTypeORM;
    @Column('varchar', { name: 'my_experience', length: 500, nullable: false })
  public myExperience: string;

  @Column('varchar', { name: 'description', length: 1000, nullable: false })
  public description: string;
  @Column('varchar', { name: 'img_applicant', length: 500, nullable: false })
  public imgApplicant: string;
}