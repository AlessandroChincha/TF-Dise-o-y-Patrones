import {Body,Controller,Delete,Get,Param,Post,Put,Res,} from '@nestjs/common';
import { RegisterPersonRequest } from '../application/dtos/request/register-person-request';
import { RegisterPersonResponse } from '../application/dtos/response/register-person-response.dto';
import { CompanyApplicationService } from '../application/services/Driver-application.service';
import { Result } from 'typescript-result';
import { AppNotification } from '../../common/application/app.notification';
import { ApiController } from '../../common/api/api.controller';
import { QueryBus } from '@nestjs/cqrs';
import { GetCustomersPersonQuery } from '../application/queries/get-customers-person.query';
import { PersonApplicationService } from '../application/services/person-application.service';
import { RegisterCompanyRequest } from '../application/dtos/request/register-company-request.dto';
import { RegisterCompanyResponse } from '../application/dtos/response/register-company-response.dto';
import { GetCustomersCompanyQuery } from '../application/queries/get-DriverId.query';
import {
  ApiBearerAuth,
  ApiOperation,
  ApiResponse,
  ApiTags,
} from '@nestjs/swagger';
import { GetAccountsDto } from 'src/accounts/application/dtos/queries/get-accounts.dto';
import { IdDriverAplicator } from '../application/validators/DriverValidator';
@ApiBearerAuth()
@ApiTags('Driver')
@Controller('Driver')
export class ClientsController {
  constructor(
    private readonly personApplicationService: PersonApplicationService,
    private readonly queryBus: QueryBus
  ) {}
  @Get(':id')
  @ApiOperation({summary: 'Get Driver by id'})
  @ApiResponse({
    status:200,description:'Driver returned', type:GetAccountsDto,
  })
  async getDriver(@Res({passthrough:true}) response): Promise<object>{
    try{
      const Drivers = await this.queryBus.execute(new GetAccountsDto());
      return ApiController.ok(response, Drivers)
    } catch(error){
      return ApiController.serverError(response,error)
    }
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get Applicant by Id' })
  @ApiResponse({
    status: 200,
    description: 'Applicant returned',
    type: GetAccountsDto,
  })

  async GetDriverID(@Param('id') id:number, @Res({passthrough:true})response,): Promise<object>{
    try{
      const resultado: Result<AppNotification, GetAccountsDto> = await this.personApplicationService.register
    }
  }
